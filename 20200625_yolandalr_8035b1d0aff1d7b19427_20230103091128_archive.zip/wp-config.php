<?php
/** 
 * Configuración básica de WordPress.
 *
 * Este archivo contiene las siguientes configuraciones: ajustes de MySQL, prefijo de tablas,
 * claves secretas, idioma de WordPress y ABSPATH. Para obtener más información,
 * visita la página del Codex{@link http://codex.wordpress.org/Editing_wp-config.php Editing
 * wp-config.php} . Los ajustes de MySQL te los proporcionará tu proveedor de alojamiento web.
 *
 * This file is used by the wp-config.php creation script during the
 * installation. You don't have to use the web site, you can just copy this file
 * to "wp-config.php" and fill in the values.
 *
 * @package WordPress
 */

// ** Ajustes de MySQL. Solicita estos datos a tu proveedor de alojamiento web. ** //
/** El nombre de tu base de datos de WordPress */
define('DB_NAME', '');


/** Tu nombre de usuario de MySQL */
define('DB_USER', '');


/** Tu contraseña de MySQL */
define('DB_PASSWORD', '');


/** Host de MySQL (es muy probable que no necesites cambiarlo) */
define('DB_HOST', '');


/** Codificación de caracteres para la base de datos. */
define('DB_CHARSET', 'utf8mb4');


/** Cotejamiento de la base de datos. No lo modifiques si tienes dudas. */
define('DB_COLLATE', '');

/**#@+
 * Claves únicas de autentificación.
 *
 * Define cada clave secreta con una frase aleatoria distinta.
 * Puedes generarlas usando el {@link https://api.wordpress.org/secret-key/1.1/salt/ servicio de claves secretas de WordPress}
 * Puedes cambiar las claves en cualquier momento para invalidar todas las cookies existentes. Esto forzará a todos los usuarios a volver a hacer login.
 *
 * @since 2.6.0
 */
define('AUTH_KEY', 'f.!)]g;*&9g *,=?_v~ayhrr/e})uL%jp^q?#rrSFCpTS2X]~zQUgCf_]Mq*IN8>');

define('SECURE_AUTH_KEY', 'hZbQ_04DHc0O#ce3,6vInOL]vD;/uty*1Z!kV5-Dt5e2-hK_GdmLh`DSX|?h3N6*');

define('LOGGED_IN_KEY', '2RW$QrG5`4?sEG9Ls3q5F@t7{a>~NAv5sc;/NSz92FQWc*8y7H|h$L-RkT(lu8R4');

define('NONCE_KEY', 'hVSMU*;b5i%.;Y/m(u1p(p724=._:F%E]vy9_m%=8lU]gW|j#m~kkHM#}X>JgkC.');

define('AUTH_SALT', 'X?$z;Ff6|QYn27D8?P-!tB)2d^.M1^1?HdRN0.IU[$F(o~b$[.XhybM4FtMI2oV4');

define('SECURE_AUTH_SALT', 'IUS{/ A(eMMXy*GB#t8-,TE%p7AS6pYx1-EQUqd~0BY9L|)=Gl=E[q}Z_aBllml~');

define('LOGGED_IN_SALT', 'E&RpD9&VlV{GlbX%*3:TFtU+.?c9f0!&U}_K04W5v[Ff*P&O,0}r/>(j56@z)C$5');

define('NONCE_SALT', 'L16p_/H[K?c76%,y5D`*`gj)$V0}+Jq{ZXna!ux1s&^wnjN#]9_`/xhm8oEt $tO');


/**#@-*/

/**
 * Prefijo de la base de datos de WordPress.
 *
 * Cambia el prefijo si deseas instalar multiples blogs en una sola base de datos.
 * Emplea solo números, letras y guión bajo.
 */
$table_prefix  = 'mm_';



/**
 * Para desarrolladores: modo debug de WordPress.
 *
 * Cambia esto a true para activar la muestra de avisos durante el desarrollo.
 * Se recomienda encarecidamente a los desarrolladores de temas y plugins que usen WP_DEBUG
 * en sus entornos de desarrollo.
 */
define('WP_DEBUG', false);

/* ¡Eso es todo, deja de editar! Feliz blogging */

/** WordPress absolute path to the Wordpress directory. */
if ( !defined('ABSPATH') )
	define('ABSPATH', dirname(__FILE__) . '/');

/** Sets up WordPress vars and included files. */
require_once(ABSPATH . 'wp-settings.php');

